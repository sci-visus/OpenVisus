#if WIN32
#  include "curlbuild.win.h"
#elif __APPLE__
#  include "curlbuild.apple.h"
#else
#  include "curlbuild.linux.h"
#endif
